package com.amigoscode.actor;

public record Actor(Integer id, String name) {
}

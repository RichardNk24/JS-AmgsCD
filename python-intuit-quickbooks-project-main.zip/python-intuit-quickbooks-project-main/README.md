# Python Intuit QuickBooks Project

## Installation
run `pip3 install -r requirements.txt`

![Screenshot 2020-11-17 at 03 03 04](https://user-images.githubusercontent.com/40702606/99343274-72664b00-2885-11eb-93dd-b048f92df409.png)
